SELECT * FROM members;
SELECT * FROM books;
SELECT * FROM loans;