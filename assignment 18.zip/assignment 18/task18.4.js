function printStudents(students) {
    console.log("Student List:");
    for (let name of students) {
        console.log(name);
    }
}

// Testing the function
printStudents(["Alice", "Bob", "Charlie"]);
