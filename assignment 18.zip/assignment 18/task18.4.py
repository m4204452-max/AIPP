def print_students(students):
    print("Student List:")
    for name in students:
        print(name)

# Testing the function
print_students(["Alice", "Bob", "Charlie"])
