// your code goes here
function printNumbers() {
  // Print the first 10 natural numbers (1 to 10) using a loop.
  for (let i = 1; i <= 10; i += 1) {
    console.log(i);
  }
}

printNumbers();